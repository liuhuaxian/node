#include "../header/mytest.h"

int main()
{
	sayhello();
	return 0;
}
