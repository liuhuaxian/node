#ifndef __MYTEST_H
#define __MYTEST_H
#include <stdio.h>
void sayhello(void);
#endif
