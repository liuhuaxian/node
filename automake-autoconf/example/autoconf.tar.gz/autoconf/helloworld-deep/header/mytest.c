#include "mytest.h"
void sayhello(void)
{
	printf("hello world!!\n");	
}
