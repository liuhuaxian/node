#include <iostream>

using namespace std;

//����⿪����Ա
class Library
{

public:
	void Step1()
	{
		cout << "Step1" << endl;
	}

	void Step3()
	{
		cout << "Step3" << endl;
	}

	void Step5()
	{
		cout << "Step5" << endl;
	}
};