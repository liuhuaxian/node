#ifndef DECOYDUCK_HPP
#define DECOYDUCK_HPP

#include "Duck.hpp"

class DecoyDuck : public Duck {
public:
    DecoyDuck();

    void display();
};

#endif