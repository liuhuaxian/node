#include "mytest.h"

int main()
{
	sayhello();
	return 0;
}
