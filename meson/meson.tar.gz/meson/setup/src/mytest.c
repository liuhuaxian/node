#include "mytest.h"
void sayhello()
{
	printf("hello world!!\n");	
}

